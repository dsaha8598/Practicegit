import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-discount',
  templateUrl: './manage-discount.component.html',
  styleUrls: ['./manage-discount.component.scss']
})
export class ManageDiscountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
