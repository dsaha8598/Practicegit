export class AirlineAndAeroplane{
    constructor(

        
    ){}
}