export class Aeroplane{
    constructor(
        public aeroplaneNumber:string,
        public businessClassCount:number,
        public economyClassCount:number,
        public startDate:Date,
        public endDate:Date
    
    ){}
}